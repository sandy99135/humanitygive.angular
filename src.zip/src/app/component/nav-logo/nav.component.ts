import { Component, OnInit } from '@angular/core';
import { Router , NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-nav-logo',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss'],
})
export class NavLogoComponent implements OnInit {

  constructor( ) {}

  ngOnInit(): void {
  }
  
}
