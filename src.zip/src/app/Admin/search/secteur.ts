export let secteurs = [
    "Réhabilitation pour Enfants Handicapés" ,
    "Soutien aux Enfants en Difficulté",
    "Accueil pour Enfants en Difficulté",
    "Orphelinat",
    "Village d'Enfants SOS",
    "Village d'Accueil pour Enfants Orphelins",
    "Maison de Transition pour Jeunes Adultes",
    "Maison de l'Enfance en Difficulté",
    "Soins pour Enfants Malades et Orphelins"
]