export let province = [
    'Mahajanga',
    'Toamasina',
    'Antananarivo',
    'Fianarantsoa',
    'Toliara',
    'Antsiranana'
]