

export let emoji : string[] = [ 
    "😀 " ,"😉"  ,"😇" , "😍" ,"😚" ,"😘" , "😁" , "🤪"  , "🤣" , "😋" , "🥳"  , "😎" , "🤐" , "😐" ,"😑" , "🙄" , "🤥" , "😬",
    "😔" , "😴" ,"🤕" , "🤢" , "😟" , "😲" , "🥺" , "😢" , "😭" , "😌" , "😱" , "😠" , "🤠"  ," 🎉"
]

export let reactions : string[] = ["😍","😃","😲","😢","😠","👍"]

// export let discution : chatDiscutionModel[] = [
//     {
//         id :'',
//         profil:'',
//         nom :"Lantoniaina",
//         text : "Kaiz Kaiz",
//         time : new Date(),
//         isRead : false,
//         notRead : 1,
//     },
//     {
//         id :'',
//         profil:'',
//         nom :"Andritoky R",
//         text : "Integrating SignalR with Angular can help developers create high-quality ",
//         time : new Date('2024-05-18'),
//         isRead : false,
//         notRead : 0,
//     },
//     {
//         id :'',
//         profil:'',
//         nom :"Mr moi meme",
//         text : "frontend apps that are reactive to user inputs in real time",
//         time : new Date('2024-05-19'),
//         isRead : false,
//         notRead : 2,
//     }
// ]

// export let detail : chatDetailModel[] = [
//     {
//         id :'',
//         position : 'gauche',
//         text : "Kaiz Kaiz 😀 ",
//         time : new Date('2024-05-01')
//     },
//     {
//         id :'',
//         position : 'droite',
//         text : "This article explores",
//         time : new Date('2024-05-01')
//     },
//     {
//         id :'',
//         position : 'gauche',
//         text : " Integrating SignalR with Angular can help developers create high-quality frontend apps that are reactive to user inputs in real time.",
//         time : new Date('2024-05-10')
//     },
//     {
//         id :'',
//         position : 'gauche',
//         text : "send and receive ",
//         time : new Date('2024-05-10')
//     },
//     {
//         id :'',
//         position : 'droite',
//         text : "SignalR connection to send and receive messages create high-quality frontend apps that are reactive ",
//         time : new Date('2024-05-11')
//     }
//     ,
//     {
//         id :'',
//         position : 'droite',
//         text : "This article explores",
//         time : new Date('2024-05-12')
//     },
//     {
//         id :'',
//         position : 'gauche',
//         text : " Integrating SignalR with Angular can help developers create high-quality frontend apps that are reactive to user inputs in real time. Integrating SignalR with Angular can help developers create high-quality frontend apps that are reactive to user inputs in real time.",
//         time : new Date('2024-05-13')
//     },
//     {
//         id :'',
//         position : 'gauche',
//         text : "testeko alou ary",
//         time : new Date('2024-05-14'),
//         reaction :"😍"
//     },
//     {
//         id :'',
//         position : 'droite',
//         text : "Dernier message",
//         time : new Date(),
        
//     }
// ]