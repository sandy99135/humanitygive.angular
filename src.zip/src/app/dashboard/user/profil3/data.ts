import { PreviewImage } from "src/app/models/image";

export let images: PreviewImage[] = [
    {
        name: "TestBed.jpg" , 
        size : 54214,
        src : "https://www.humanium.org/fr/wp-content/uploads/2021/01/shutterstock_1844236675-1024x683.jpg",
    },
    {
        name: "Test.jpg" , 
        size : 54214,
        src : "https://www.humanium.org/fr/wp-content/uploads/2020/10/shutterstock_667950202-scaled.jpg",
    }
    ,
    {
        name: "Test.jpg" , 
        size : 54214,
        src : "https://www.humanium.org/fr/wp-content/uploads/2020/10/shutterstock_667950202-scaled.jpg",
    }
    ,
    {
        name: "Test.jpg" , 
        size : 54214,
        src : "https://gumlet.assettype.com/creativegaga%2F2022-05%2F27ac6a88-4da9-47dc-af50-71dd432c5a31%2FNaveen_Selvanathan_2.jpg",
    }
]