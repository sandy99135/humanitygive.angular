export let images = [
    "https://www.humanium.org/fr/wp-content/uploads/2021/01/shutterstock_1844236675-1024x683.jpg",
    "https://www.humanium.org/fr/wp-content/uploads/2020/10/shutterstock_667950202-scaled.jpg",
    "https://www.humanium.org/fr/wp-content/uploads/2021/01/shutterstock_1844236675-1024x683.jpg",
    "https://www.humanium.org/fr/wp-content/uploads/2020/10/shutterstock_667950202-scaled.jpg"
]