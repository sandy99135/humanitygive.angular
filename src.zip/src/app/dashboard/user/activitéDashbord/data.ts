export let  parainage = [
    {nom : "Nom et Prénom" , ass : "Assxxxxx xxxxx"} ,
    {nom : "Nom et Prénom" , ass : "Assxxxxx "} ,
];