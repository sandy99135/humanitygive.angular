export let data = [
    {
        denomination : 'Etablissement Tsarakoloina',
        Adresse : 'Ambohimirary Antananarivo 5em Arrondissement',
        Contacte : '0348855268',
        Type : 'Ecole'
    },
    {
        denomination : 'Bethel',
        Adresse : 'Analamahintsy Antananarivo 3em Arrondissement',
        Contacte : '0348855268',
        Type : 'Association'
    },
    {
        denomination : 'Akany Mafinaritra',
        Adresse : 'Nanisana Antananarivo 5em Arrondissement',
        Contacte : '0348855268',
        Type : 'Village'
    },
    {
        denomination : 'Etablissement Tsarakoloina',
        Adresse : 'Ambohimirary Antananarivo 5em Arrondissement',
        Contacte : '0348855268',
        Type : 'Village'
    },
    {
        denomination : 'Bethel',
        Adresse : 'Tanambao Ambatondrazaka',
        Contacte : '0348855268',
        Type : 'Ecole privée'
    },
    {
        denomination : 'Akany Soafeno',
        Adresse : 'Ambohimirary Antananarivo 5em Arrondissement',
        Contacte : '0348855268',
        Type : 'Association'
    },
]