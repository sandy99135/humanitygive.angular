export class Particulier {
    "email" : string;
    "type" : number;
    "notification" : boolean;
    "fullName" : string ;
    "Nationnalite" : string ;
    "addresse" : string ;
    "sex" : 0 ;
    "professionnalSituation" : string | null;
    "password" : string ;
    "phoneNumber" : string 
    "province" : string;
    "region" : string;
    "district" : string;
    "commune" : string;
    "fokotany" : string;
  }
  