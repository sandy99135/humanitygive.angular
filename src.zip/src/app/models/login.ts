export class Login {
  matricule!: string | null;
  mdp!: string | null;
}
