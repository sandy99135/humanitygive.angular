export class Professionnel {
    "email" : string;
    "type" : number;
    "notification" : boolean;
    "fullName" : string ;
    "sectorActivity" : string ;
    "pays" : string ;
    "addresse" : string ;
    "password" : string ;
    "phoneNumber" : string 
    "province" : string;
    "region" : string;
    "district" : string;
    "commune" : string;
    "fokotany" : string;
  }
  