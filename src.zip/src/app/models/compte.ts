export class ResetMdp {
        "id" !: string;
        "actualPassord": string;
        "newPassord": string ;
        "confirmNewPassword": string ;
        "isForgotten": boolean ;
        "email": string;
    }

   