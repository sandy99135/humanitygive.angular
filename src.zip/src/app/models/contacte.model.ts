export class ContacteModel {
    "id"?: string;
    "fullName": string;
    "email": string;
    "phoneNumber": string;
    "message": string
}

